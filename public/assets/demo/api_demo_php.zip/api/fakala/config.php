<?php

return array(
    'gateway' => 'http://card.evil5.com',
    'api_id' => '3',
    'api_key' => '7a8e0efbbf3f4923e5343fd6897e4537'
);